from django.contrib import admin
from .models import Category, New


admin.site.register(Category)
admin.site.register(New)